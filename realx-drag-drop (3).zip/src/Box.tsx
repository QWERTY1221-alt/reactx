import type { CSSProperties, FC } from "react";
import type { DragSourceMonitor } from "react-dnd";
import { useDrag } from "react-dnd";
import React from "react";
import ReactDOM from "react-dom";

import { ItemTypes } from "./ItemTypes";

const style: CSSProperties = {
  border: "1px dashed gray",
  backgroundColor: "white",
  width: "45px",
  height: "45px",
  marginRight: "1.5rem",
  marginBottom: "1.5rem",
  float: "left"
};

export interface BoxProps {
  name: string;
  id: string;
}

interface DropResult {
  allowedDropEffect: string;
  dropEffect: string;
  name: string;
  id: string;
}

export const Box: FC<BoxProps> = ({ name }) => {
  const [{ opacity }, drag] = useDrag(
    () => ({
      type: ItemTypes.BOX,
      item: { name },
      end(item, monitor) {
        const dropResult = monitor.getDropResult() as DropResult;
        if (item && dropResult) {
          let alertMessage = "";
          const isDropAllowed =
            dropResult.allowedDropEffect === "any1" ||
            dropResult.allowedDropEffect === dropResult.dropEffect;

          const isDropAllowed2 =
            dropResult.allowedDropEffect === "any2" ||
            dropResult.allowedDropEffect === dropResult.dropEffect;

          const isDropAllowed3 =
            dropResult.allowedDropEffect === "any3" ||
            dropResult.allowedDropEffect === dropResult.dropEffect;

          const isDropAllowed4 =
            dropResult.allowedDropEffect === "any4" ||
            dropResult.allowedDropEffect === dropResult.dropEffect;

          const isDropAllowed5 =
            dropResult.allowedDropEffect === "any5" ||
            dropResult.allowedDropEffect === dropResult.dropEffect;

          const isDropAllowed6 =
            dropResult.allowedDropEffect === "any6" ||
            dropResult.allowedDropEffect === dropResult.dropEffect;

          const isDropAllowed7 =
            dropResult.allowedDropEffect === "any7" ||
            dropResult.allowedDropEffect === dropResult.dropEffect;

          if (isDropAllowed) {
            const isCopyAction = dropResult.dropEffect === "copy";
            const actionName = isCopyAction ? "copied" : "moved";
            alertMessage = `${item.name}`;
            let demo = React.createElement(
              "div",
              {
                style: {
                  background: alertMessage,
                  width: "45px",
                  height: "45px"
                }
              },
              alertMessage
            );
            ReactDOM.render(demo, document.getElementById("any1"));
          } else {
          }

          if (isDropAllowed2) {
            const isCopyAction = dropResult.dropEffect === "copy";
            const actionName = isCopyAction ? "copied" : "moved";
            alertMessage = `${item.name}`;
            let demo = React.createElement(
              "div",
              {
                style: {
                  background: alertMessage,
                  width: "45px",
                  height: "45px"
                }
              },
              alertMessage
            );
            ReactDOM.render(demo, document.getElementById("any2"));
          } else {
          }

          if (isDropAllowed3) {
            const isCopyAction = dropResult.dropEffect === "copy";
            const actionName = isCopyAction ? "copied" : "moved";
            alertMessage = `${item.name}`;
            let demo = React.createElement(
              "div",
              {
                style: {
                  background: alertMessage,
                  width: "45px",
                  height: "45px"
                }
              },
              alertMessage
            );
            ReactDOM.render(demo, document.getElementById("any3"));
          } else {
          }

          if (isDropAllowed4) {
            const isCopyAction = dropResult.dropEffect === "copy";
            const actionName = isCopyAction ? "copied" : "moved";
            alertMessage = `${item.name}`;
            let demo = React.createElement(
              "div",
              {
                style: {
                  background: alertMessage,
                  width: "45px",
                  height: "45px"
                }
              },
              alertMessage
            );
            ReactDOM.render(demo, document.getElementById("any4"));
          } else {
          }

          if (isDropAllowed5) {
            const isCopyAction = dropResult.dropEffect === "copy";
            const actionName = isCopyAction ? "copied" : "moved";
            alertMessage = `${item.name}`;
            let demo = React.createElement(
              "div",
              {
                style: {
                  background: alertMessage,
                  width: "45px",
                  height: "45px"
                }
              },
              alertMessage
            );
            ReactDOM.render(demo, document.getElementById("any5"));
          } else {
          }

          if (isDropAllowed6) {
            const isCopyAction = dropResult.dropEffect === "copy";
            const actionName = isCopyAction ? "copied" : "moved";
            alertMessage = `${item.name}`;
            let demo = React.createElement(
              "div",
              {
                style: {
                  background: alertMessage,
                  width: "45px",
                  height: "45px"
                }
              },
              alertMessage
            );
            ReactDOM.render(demo, document.getElementById("any6"));
          } else {
          }

          if (isDropAllowed7) {
            const isCopyAction = dropResult.dropEffect === "copy";
            const actionName = isCopyAction ? "copied" : "moved";
            alertMessage = `${item.name}`;
            let demo = React.createElement(
              "div",
              {
                style: {
                  background: alertMessage,
                  width: "45px",
                  height: "45px"
                }
              },
              alertMessage
            );
            ReactDOM.render(demo, document.getElementById("any7"));
          } else {
          }
          console.log(alertMessage);
        }
      },
      collect: (monitor: DragSourceMonitor) => ({
        opacity: monitor.isDragging() ? 0.8 : 1
      })
    }),
    [name]
  );

  return (
    <div id={name} ref={drag} style={{ ...style, opacity, cursor: "pointer" }}>
      {name}
      <script></script>
    </div>
  );
};
