import type { FC } from "react";
import React from "react";
import { Base64 } from "js-base64";
import { Box } from "./Box";
import { Dustbin } from "./Dustbin";
import raw from "./foo.txt";

fetch(raw)
  .then((r) => r.text())
  .then((text) => {
    console.log(text);
  });

export const Container: FC = () => (
  <div>
    <div style={{ overflow: "hidden", clear: "both" }}>
      <div>
        <Box name="red" />
      </div>
      <div>
        <Box name="yellow" />
      </div>
      <div>
        <Box name="blue" />
      </div>
      <div>
        <Box name="green" />
      </div>
      <div>
        <Box name="brown" />
      </div>
      <div>
        <Box name="purple" />
      </div>
      <div>
        <Box name="gray" />
      </div>
      <div id="AAA">
        <Box name={Base64.decode(raw)} />
      </div>
    </div>
    <div id="results" style={{ overflow: "hidden", clear: "both" }}>
      <Dustbin allowedDropEffect="any1" />
      <Dustbin allowedDropEffect="any2" />
      <Dustbin allowedDropEffect="any3" />
      <Dustbin allowedDropEffect="any4" />
      <Dustbin allowedDropEffect="any5" />
      <Dustbin allowedDropEffect="any6" />
      <Dustbin allowedDropEffect="any7" />
    </div>
  </div>
);
