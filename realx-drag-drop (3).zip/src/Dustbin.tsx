import { url } from "inspector";
import type { CSSProperties, FC } from "react";
import { useDrop } from "react-dnd";

import { ItemTypes } from "./ItemTypes";

const style: CSSProperties = {
  height: "12rem",
  width: "12rem",
  marginRight: "1.5rem",
  marginBottom: "1.5rem",
  color: "white",
  padding: "1rem",
  textAlign: "center",
  fontSize: "1rem",
  lineHeight: "normal",
  float: "left"
};

export interface DustbinProps {
  allowedDropEffect: string;
}

export const Dustbin: FC<DustbinProps> = ({ allowedDropEffect }) => {
  const [{ canDrop, isOver }, drop] = useDrop(
    () => ({
      accept: ItemTypes.BOX,
      drop: () => ({
        name: `${allowedDropEffect} Dustbin`,
        allowedDropEffect
      }),
      collect: (monitor: any) => ({
        isOver: monitor.isOver(),
        canDrop: monitor.canDrop()
      })
    }),
    [allowedDropEffect]
  );

  const isActive = canDrop && isOver;
  return (
    <div
      id={`${allowedDropEffect}`}
      ref={drop}
      style={{
        width: "45px",
        height: "45px",
        backgroundImage: `url(${process.env.PUBLIC_URL + "/image.png"})`,
        border: "1px black solid"
      }}
    >
      {`${allowedDropEffect}`}
      {isActive ? "drop" : "here"}
    </div>
  );
};
