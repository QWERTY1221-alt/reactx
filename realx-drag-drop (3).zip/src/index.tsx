import { render } from "react-dom";
import Example from "./example";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import React from "react";
import ReactDOM from "react-dom";

function App() {
  return (
    <div className="App">
      <DndProvider backend={HTML5Backend}>
        <Example />
      </DndProvider>
    </div>
  );
}

const rootElement = document.getElementById("root");
render(<App />, rootElement);

let inv1 = React.createElement(
  "div",
  { style: { background: "red", width: "100%", height: "100%" }, id: "someId" },
  "red"
);
ReactDOM.render(inv1, document.getElementById("red"));

let inv2 = React.createElement(
  "div",
  { style: { background: "yellow", width: "100%", height: "100%" } },
  "yellow"
);
ReactDOM.render(inv2, document.getElementById("yellow"));

let demo2 = React.createElement(
  "div",
  {
    style: {
      width: "45px",
      height: "45px"
    }
  },
  "rest"
);
ReactDOM.render(demo2, document.getElementById("any1"));
